# Quick Setup Guide

## Step-by-Step Installation

### 1. Install Python Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up Database
```bash
python manage.py makemigrations
python manage.py migrate
```

### 3. Create Admin Account
```bash
python manage.py createsuperuser
```
Follow the prompts to create your admin account.

### 4. Run the Server
```bash
python manage.py runserver
```

### 5. Access the Application
- Main Application: http://127.0.0.1:8000/
- Admin Panel: http://127.0.0.1:8000/admin/

## Initial Configuration

### As Admin:

1. **Login** with your superuser credentials

2. **Add Parking Slots:**
   - Go to Admin → Slots → Add New Slot
   - Example: Slot "A1", Floor 1, Status: Available
   - Add multiple slots as needed

3. **Configure Pricing:**
   - Go to Admin → Pricing
   - Set your rates:
     - Price Per Hour: $10.00
     - First Hour Rate: $10.00
     - Additional Hour Rate: $10.00
   - Click "Update Pricing"

4. **Test the System:**
   - Create a test user account (or register as a new user)
   - Login as the test user
   - Book a slot
   - Checkout to see the pricing calculation

## Sample Data (Optional)

You can manually add sample data through the admin interface or use Django shell:

```python
python manage.py shell
```

Then run:
```python
from parking.models import ParkingSlot, Pricing

# Create some slots
for i in range(1, 11):
    ParkingSlot.objects.create(
        slot_number=f"A{i}",
        floor_number=1,
        status='available'
    )

# Ensure pricing exists
Pricing.get_current_pricing()
```

## Troubleshooting

### Database Issues
If you get database errors:
```bash
python manage.py migrate --run-syncdb
```

### Static Files
If styles don't load:
```bash
python manage.py collectstatic
```

### Port Already in Use
If port 8000 is busy:
```bash
python manage.py runserver 8001
```

## Next Steps

1. Customize the pricing rules
2. Add more parking slots
3. Create user accounts
4. Start booking slots!

For more details, see README.md

