"""
URL configuration for parking_system project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from django.urls import path



urlpatterns = [
    # Custom admin pages - must come before Django admin
    path('', include('parking.urls')),
    # Django admin panel (moved to avoid conflict with custom admin URLs)
    path('django-admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

