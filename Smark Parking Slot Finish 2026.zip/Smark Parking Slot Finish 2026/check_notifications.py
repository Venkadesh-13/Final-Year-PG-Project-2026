import os
import django
from django.utils import timezone

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'parking_system.settings')
django.setup()

from parking.models import Notification

def check_notifications():
    total = Notification.objects.count()
    sent = Notification.objects.filter(email_sent=True).count()
    not_sent = Notification.objects.filter(email_sent=False).count()
    print(f"Total Notifications: {total}")
    print(f"Sent: {sent}")
    print(f"Not Sent: {not_sent}")
    
    print("\nRecent 10 notifications:")
    notifications = Notification.objects.all().order_by('-created_at')[:10]
    print(f"{'Type':<25} | {'Email Sent':<10} | {'Email Address':<30} | {'Created At':<20}")
    print("-" * 100)
    for n in notifications:
        email = n.booking.driver_email or n.user.email or "N/A"
        print(f"{n.notification_type:<25} | {str(n.email_sent):<10} | {email:<30} | {n.created_at.strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    check_notifications()
