# Gmail Email Configuration Instructions

## Step-by-Step Setup for venkadesh132004@gmail.com

### Step 1: Enable 2-Step Verification

1. Go to your Google Account: https://myaccount.google.com
2. Click on **Security** (left sidebar)
3. Under "Signing in to Google", find **2-Step Verification**
4. Click on it and follow the prompts to enable 2-Step Verification
5. You'll need to verify your phone number

### Step 2: Generate App Password

1. After enabling 2-Step Verification, go back to **Security**
2. Under "Signing in to Google", you'll now see **App passwords**
3. Click on **App passwords**
4. You may need to sign in again
5. Select **Mail** as the app
6. Select **Other (Custom name)** as the device
7. Enter "Parking Booking System" as the name
8. Click **Generate**
9. **Copy the 16-character password** (it will look like: `abcd efgh ijkl mnop`)

### Step 3: Configure Django Settings

1. Open `parking_system/settings.py`
2. Find the email configuration section
3. Replace `EMAIL_HOST_PASSWORD` with your app password:

```python
EMAIL_HOST_PASSWORD = 'your-16-character-app-password'  # Remove spaces from the password
```

**OR** use environment variable (recommended for security):

1. Create a `.env` file in the project root (if it doesn't exist)
2. Add this line:
```
EMAIL_HOST_PASSWORD=your16characterapppassword
```

3. Update `settings.py` to use:
```python
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
```

### Step 4: Test Email Configuration

1. Run the Django server:
   ```bash
   python manage.py runserver
   ```

2. Create a test booking in the system
3. Check your email inbox (venkadesh132004@gmail.com)
4. You should receive:
   - Booking confirmation email with QR code attachment
   - Checkout email with PDF invoice attachment

### Important Notes

- **Never share your App Password** - it's like a password
- **App Passwords are 16 characters** - remove spaces when entering
- If you change your Google password, you'll need to generate a new App Password
- The system will send emails to:
  - The customer (booking user)
  - You (venkadesh132004@gmail.com) as admin copy

### Troubleshooting

**"Authentication failed" error:**
- Make sure you're using App Password, not your regular Gmail password
- Verify 2-Step Verification is enabled
- Check that the password has no spaces

**"Connection refused" error:**
- Check your internet connection
- Verify firewall isn't blocking port 587
- Try using port 465 with SSL instead (change EMAIL_PORT to 465 and EMAIL_USE_TLS to False, EMAIL_USE_SSL to True)

**Emails not sending:**
- Check spam folder
- Verify EMAIL_HOST_PASSWORD is set correctly
- Check Django console for error messages
- Make sure EMAIL_BACKEND is set to 'django.core.mail.backends.smtp.EmailBackend'

### Current Configuration

Your email is configured as:
- **From Email**: venkadesh132004@gmail.com
- **SMTP Server**: smtp.gmail.com
- **Port**: 587
- **TLS**: Enabled
- **Admin Email**: venkadesh132004@gmail.com (receives copies of all bookings)

### Security Best Practices

1. **Don't commit passwords to Git** - use environment variables
2. **Use App Passwords** - never use your main Gmail password
3. **Keep App Passwords secure** - treat them like passwords
4. **Rotate App Passwords** periodically for security

---

**Need Help?**
- Gmail App Password Help: https://support.google.com/accounts/answer/185833
- Django Email Documentation: https://docs.djangoproject.com/en/stable/topics/email/

