import os
import django
from django.utils import timezone

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'parking_system.settings')
django.setup()

from parking.models import Booking, Notification
from parking.utils import send_booking_confirmation

def test_actual_function():
    print("Testing send_booking_confirmation from utils.py...")
    # Get the latest booking
    booking = Booking.objects.all().order_by('-created_at').first()
    if not booking:
        print("No bookings found to test with.")
        return
    
    print(f"Using Booking ID: {booking.id}, Email: {booking.driver_email or booking.user.email}")
    
    # Check current notification status
    prev_notif = Notification.objects.filter(booking=booking, notification_type='booking_confirmation').order_by('-created_at').first()
    if prev_notif:
        print(f"Previous notification email_sent: {prev_notif.email_sent}")

    try:
        send_booking_confirmation(booking)
        
        # Check if a new notification was created and its status
        new_notif = Notification.objects.filter(booking=booking, notification_type='booking_confirmation').order_by('-created_at').first()
        if new_notif:
            print(f"New notification ID: {new_notif.id}")
            print(f"New notification email_sent: {new_notif.email_sent}")
            if not new_notif.email_sent:
                print("FAILED: Notification.email_sent is still False.")
            else:
                print("SUCCESS: Notification.email_sent is True!")
        else:
            print("FAILED: No notification created.")
    except Exception as e:
        print(f"Caught exception in test script: {e}")

if __name__ == "__main__":
    test_actual_function()
