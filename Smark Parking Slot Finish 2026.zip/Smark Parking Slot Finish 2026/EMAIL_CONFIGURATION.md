# Email Configuration Guide

This guide explains how to configure email settings for the Parking Booking System.

## Email Features

The system sends emails for:
1. **Booking Confirmation** - Sent when a user books a slot (includes QR code attachment)
2. **Checkout Summary** - Sent when a user checks out (includes PDF invoice attachment)

## Configuration Steps

### For Gmail (Recommended for Development)

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate an App Password**:
   - Go to Google Account Settings
   - Security → 2-Step Verification → App passwords
   - Generate a new app password for "Mail"
   - Copy the 16-character password

3. **Update `parking_system/settings.py`**:

```python
# Email Configuration
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'  # Your Gmail address
EMAIL_HOST_PASSWORD = 'your-app-password'  # The 16-character app password
DEFAULT_FROM_EMAIL = 'your-email@gmail.com'
```

### For Other SMTP Servers

#### Outlook/Hotmail
```python
EMAIL_HOST = 'smtp-mail.outlook.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@outlook.com'
EMAIL_HOST_PASSWORD = 'your-password'
DEFAULT_FROM_EMAIL = 'your-email@outlook.com'
```

#### Yahoo Mail
```python
EMAIL_HOST = 'smtp.mail.yahoo.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@yahoo.com'
EMAIL_HOST_PASSWORD = 'your-app-password'
DEFAULT_FROM_EMAIL = 'your-email@yahoo.com'
```

#### Custom SMTP Server
```python
EMAIL_HOST = 'smtp.yourdomain.com'
EMAIL_PORT = 587  # or 465 for SSL
EMAIL_USE_TLS = True  # Set to False if using SSL
EMAIL_USE_SSL = False  # Set to True if using SSL on port 465
EMAIL_HOST_USER = 'noreply@yourdomain.com'
EMAIL_HOST_PASSWORD = 'your-password'
DEFAULT_FROM_EMAIL = 'noreply@yourdomain.com'
```

## Environment Variables (Recommended for Production)

For better security, use environment variables:

1. Install `django-environ` (already in requirements.txt)
2. Create a `.env` file in the project root:

```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
DEFAULT_FROM_EMAIL=your-email@gmail.com
```

3. Update `settings.py`:

```python
import environ

env = environ.Env()
environ.Env.read_env()

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = env('EMAIL_HOST', default='smtp.gmail.com')
EMAIL_PORT = int(env('EMAIL_PORT', default=587))
EMAIL_USE_TLS = env('EMAIL_USE_TLS', default='True').lower() == 'true'
EMAIL_HOST_USER = env('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = env('EMAIL_HOST_PASSWORD', default='')
DEFAULT_FROM_EMAIL = env('DEFAULT_FROM_EMAIL', default='noreply@smartparking.com')
```

## Testing Email Configuration

### Development Mode (Console Backend)

For testing without sending real emails, use the console backend:

```python
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
```

Emails will be printed to the console/terminal.

### Testing Real Email

1. Configure SMTP settings as shown above
2. Create a test booking
3. Check your email inbox (and spam folder)
4. Verify that:
   - Booking confirmation email includes QR code attachment
   - Checkout email includes PDF invoice attachment

## Troubleshooting

### Common Issues

1. **"Authentication failed"**
   - Verify your email and password are correct
   - For Gmail, ensure you're using an App Password, not your regular password
   - Check that 2FA is enabled (for Gmail)

2. **"Connection refused"**
   - Check firewall settings
   - Verify SMTP server and port are correct
   - Some networks block SMTP ports

3. **"Emails going to spam"**
   - Add the sender email to contacts
   - Configure SPF/DKIM records for your domain (for production)

4. **"SSL/TLS errors"**
   - Verify `EMAIL_USE_TLS` and `EMAIL_USE_SSL` settings
   - Check port number (587 for TLS, 465 for SSL)

## Production Recommendations

1. Use a dedicated email service (SendGrid, Mailgun, AWS SES)
2. Set up proper SPF, DKIM, and DMARC records
3. Use environment variables for sensitive credentials
4. Monitor email delivery rates
5. Implement email queuing (Celery) for better performance

## Support

For issues or questions, refer to Django's email documentation:
https://docs.djangoproject.com/en/stable/topics/email/

