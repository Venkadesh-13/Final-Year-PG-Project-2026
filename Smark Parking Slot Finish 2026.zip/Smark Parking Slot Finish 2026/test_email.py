import os
import django
from django.core.mail import send_mail
from django.conf import settings

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'parking_system.settings')
django.setup()

def test_email():
    print(f"Testing email with settings:")
    print(f"EMAIL_HOST: {settings.EMAIL_HOST}")
    print(f"EMAIL_PORT: {settings.EMAIL_PORT}")
    print(f"EMAIL_HOST_USER: {settings.EMAIL_HOST_USER}")
    
    try:
        subject = 'Test Email from Smart Parking System'
        message = 'This is a test email to verify the SMTP configuration.'
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = ['suryasingamdubuku@gmail.com']  # Send to the user's email
        
        result = send_mail(subject, message, from_email, recipient_list)
        if result:
            print("Successfully sent test email!")
        else:
            print("Failed to send test email (returned 0).")
    except Exception as e:
        print(f"Error occurred while sending email: {e}")

if __name__ == "__main__":
    test_email()
