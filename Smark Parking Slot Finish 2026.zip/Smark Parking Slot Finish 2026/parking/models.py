from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator
from decimal import Decimal


class User(AbstractUser):
    """Custom User model with role field"""
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('user', 'User'),
    ]
    
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')
    phone = models.CharField(max_length=15, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.username} ({self.role})"
    
    def is_admin_user(self):
        return self.role == 'admin' or self.is_superuser
    
    @property
    def is_admin(self):
        """Property for template usage"""
        return self.role == 'admin' or self.is_superuser


class Pricing(models.Model):
    """Pricing configuration for parking"""
    price_per_hour = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        validators=[MinValueValidator(Decimal('0.01'))],
        default=Decimal('10.00'),
        help_text="Rate per hour"
    )
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name_plural = "Pricing"
    
    def __str__(self):
        return f"Rs.{self.price_per_hour}/hour"
    
    @classmethod
    def get_current_pricing(cls):
        """Get the current pricing configuration"""
        pricing = cls.objects.first()
        if not pricing:
            pricing = cls.objects.create()
        return pricing


class VehicleCategory(models.Model):
    """Vehicle category model"""
    CATEGORY_CHOICES = [
        ('car', 'Four Wheeler (Car/Sedan)'),
        ('motorcycle', 'Two Wheeler (Motorcycle/Scooter)'),
        ('suv', 'Large Four Wheeler (SUV)'),
        ('van', 'Van / Minivan'),
        ('truck', 'Heavy Vehicle (Truck/Bus)'),
        ('bicycle', 'Bicycle'),
    ]
    
    name = models.CharField(max_length=50, choices=CATEGORY_CHOICES, unique=True)
    description = models.TextField(blank=True)
    multiplier = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        default=Decimal('1.00'),
        help_text="Price multiplier for this category (1.0 = normal, 1.5 = 50% more, etc.)"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name_plural = "Vehicle Categories"
        ordering = ['name']
    
    def __str__(self):
        return self.get_name_display()


class ParkingSlot(models.Model):
    """Parking slot model"""
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('booked', 'Booked'),
        ('maintenance', 'Under Maintenance'),
    ]
    
    slot_number = models.CharField(max_length=50, unique=True)
    floor_number = models.IntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    vehicle_category = models.ForeignKey('VehicleCategory', on_delete=models.SET_NULL, null=True, blank=True, help_text="Restricted to specific vehicle category (optional)")
    is_covered = models.BooleanField(default=False, help_text="Is this slot covered/sheltered?")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['floor_number', 'slot_number']
    
    def __str__(self):
        return f"Floor {self.floor_number} - Slot {self.slot_number} ({self.status})"


class Booking(models.Model):
    """Booking model for parking slots"""
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    ENTRY_STATUS_CHOICES = [
        ('pending', 'Pending Entry'),
        ('entered', 'Entered'),
        ('exited', 'Exited'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    slot = models.ForeignKey(ParkingSlot, on_delete=models.CASCADE, related_name='bookings')
    vehicle_category = models.ForeignKey(VehicleCategory, on_delete=models.SET_NULL, null=True, blank=True)
    vehicle_number = models.CharField(max_length=50)
    vehicle_make = models.CharField(max_length=50, blank=True, help_text="e.g., Toyota, Honda")
    vehicle_model = models.CharField(max_length=50, blank=True, help_text="e.g., Camry, Civic")
    vehicle_color = models.CharField(max_length=30, blank=True)
    driver_name = models.CharField(max_length=100, blank=True)
    driver_phone = models.CharField(max_length=15, blank=True)
    driver_email = models.EmailField(blank=True)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(null=True, blank=True)
    entry_time = models.DateTimeField(null=True, blank=True, help_text="Actual entry time")
    exit_time = models.DateTimeField(null=True, blank=True, help_text="Actual exit time")
    entry_status = models.CharField(max_length=20, choices=ENTRY_STATUS_CHOICES, default='pending')
    pass_key = models.CharField(max_length=20, unique=True, null=True, blank=True, help_text="Unique pass key for verification")
    total_hours = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    total_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    notes = models.TextField(blank=True, help_text="Additional notes or special instructions")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Booking {self.id} - {self.user.username} - {self.slot.slot_number}"
    
    def generate_pass_key(self):
        """Generate unique pass key for this booking"""
        import secrets
        import string
        if not self.pass_key:
            # Generate a 8-character alphanumeric pass key
            alphabet = string.ascii_uppercase + string.digits
            while True:
                pass_key = ''.join(secrets.choice(alphabet) for _ in range(8))
                # Ensure uniqueness
                if not Booking.objects.filter(pass_key=pass_key).exists():
                    self.pass_key = pass_key
                    self.save()
                    break
        return self.pass_key
    
    def calculate_price(self):
        """Calculate total price based on actual usage time (entry to exit)
        Uses simple per hour rate - automatically calculates if user extends beyond booked time"""
        from django.utils import timezone
        
        # Use actual entry time if available, otherwise use booked start_time
        actual_start = self.entry_time if self.entry_time else self.start_time
        
        # Use exit_time if available, otherwise use current time
        actual_end = self.exit_time if self.exit_time else timezone.now()
        
        if not actual_start or not actual_end:
            return None
        
        # Calculate actual usage duration
        actual_duration = actual_end - actual_start
        actual_hours = actual_duration.total_seconds() / 3600
        
        # Round up to nearest hour
        total_hours_rounded = int(actual_hours) + (1 if actual_hours % 1 > 0 else 0)
        
        pricing = Pricing.get_current_pricing()
        
        # Simple per hour calculation
        price = pricing.price_per_hour * total_hours_rounded
        
        # Apply vehicle category multiplier
        if self.vehicle_category:
            price = price * self.vehicle_category.multiplier
        
        self.total_hours = Decimal(str(total_hours_rounded))
        self.total_price = price
        return price
    
    def checkout(self, payment_method=None):
        """Complete the booking and update slot status"""
        from django.utils import timezone
        if not self.end_time:
            self.end_time = timezone.now()
        if not self.exit_time:
            self.exit_time = timezone.now()
        
        # Calculate price based on actual usage time
        self.calculate_price()
        self.status = 'completed'
        self.entry_status = 'exited'
        self.save()
        
        # Update slot status to available
        self.slot.status = 'available'
        self.slot.save()
        
        # Send checkout notification only if payment_method is provided (payment completed)
        if payment_method:
            try:
                from .utils import send_checkout_notification
                send_checkout_notification(self, payment_method)
            except Exception as e:
                print(f"Error sending checkout notification: {e}")  # Don't fail if notification fails


class Payment(models.Model):
    """Payment model for booking transactions"""
    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('upi', 'UPI QR'),
        ('stripe', 'Stripe'),
        ('paypal', 'PayPal'),
        ('card', 'Card'),
        ('online', 'Online'),
    ]
    
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='payments')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='stripe')
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=255, blank=True, null=True, help_text="Payment gateway transaction ID")
    payment_date = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Payment {self.id} - Rs.{self.amount} - {self.payment_status}"


class Notification(models.Model):
    """Notification model for booking confirmations and checkout summaries"""
    NOTIFICATION_TYPES = [
        ('booking_confirmation', 'Booking Confirmation'),
        ('checkout_summary', 'Checkout Summary'),
        ('booking_cancelled', 'Booking Cancelled'),
        ('entry_confirmed', 'Entry Confirmed'),
        ('exit_confirmed', 'Exit Confirmed'),
        ('reminder', 'Reminder'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='notifications')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=30, choices=NOTIFICATION_TYPES)
    title = models.CharField(max_length=200)
    message = models.TextField()
    email_sent = models.BooleanField(default=False)
    sms_sent = models.BooleanField(default=False)
    read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.notification_type} - {self.user.username} - {self.created_at}"
