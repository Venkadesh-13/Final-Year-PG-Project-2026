from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from io import BytesIO
from django.db.models import Count, Sum, Q
from django.utils import timezone
from datetime import datetime, timedelta
from decimal import Decimal
import json

from .models import User, ParkingSlot, Booking, Pricing, VehicleCategory, Notification, Payment
from .forms import UserRegistrationForm, ParkingSlotForm, BookingForm, PricingForm
from .utils import (
    send_booking_confirmation,
    send_checkout_notification,
    generate_pdf_invoice,
    send_booking_cancellation,
    send_user_registration_email,
    send_checkin_notification,
)


def is_admin(user):
    return user.is_authenticated and (user.is_admin_user() or user.is_superuser)


# Authentication Views
def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Send registration email
            try:
                send_user_registration_email(user)
            except Exception as e:
                print(f"Error sending registration email: {e}")
            messages.success(request, 'Registration successful! Please login.')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'parking/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'parking/login.html')


# Dashboard
@login_required
def dashboard(request):
    if request.user.is_admin_user():
        return admin_dashboard(request)
    else:
        return user_dashboard(request)


@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    # Statistics
    total_slots = ParkingSlot.objects.count()
    available_slots = ParkingSlot.objects.filter(status='available').count()
    booked_slots = ParkingSlot.objects.filter(status='booked').count()
    maintenance_slots = ParkingSlot.objects.filter(status='maintenance').count()
    total_users = User.objects.filter(role='user').count()
    total_bookings = Booking.objects.count()
    active_bookings = Booking.objects.filter(status='active').count()
    
    # Revenue calculation
    completed_bookings = Booking.objects.filter(status='completed')
    total_revenue = completed_bookings.aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Today's revenue
    today = timezone.now().date()
    today_revenue = completed_bookings.filter(
        end_time__date=today
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Weekly revenue (last 7 days)
    week_ago = timezone.now() - timedelta(days=7)
    weekly_revenue = completed_bookings.filter(
        end_time__gte=week_ago
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Monthly revenue (last 30 days)
    month_ago = timezone.now() - timedelta(days=30)
    monthly_revenue = completed_bookings.filter(
        end_time__gte=month_ago
    ).aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Recent bookings
    recent_bookings = Booking.objects.all()[:10]
    
    context = {
        'total_slots': total_slots,
        'available_slots': available_slots,
        'booked_slots': booked_slots,
        'maintenance_slots': maintenance_slots,
        'total_users': total_users,
        'total_bookings': total_bookings,
        'active_bookings': active_bookings,
        'total_revenue': total_revenue,
        'today_revenue': today_revenue,
        'weekly_revenue': weekly_revenue,
        'monthly_revenue': monthly_revenue,
        'recent_bookings': recent_bookings,
    }
    return render(request, 'parking/admin/dashboard.html', context)


@login_required
def user_dashboard(request):
    # Get available slots
    available_slots = ParkingSlot.objects.filter(status='available')
    booked_slots = ParkingSlot.objects.filter(status='booked')
    maintenance_slots = ParkingSlot.objects.filter(status='maintenance')
    
    # Get user's active booking
    active_booking = Booking.objects.filter(user=request.user, status='active').first()
    
    # Get user's recent bookings
    recent_bookings = Booking.objects.filter(user=request.user).order_by('-created_at')[:5]
    
    # Group slots by floor
    slots_by_floor = {}
    for slot in ParkingSlot.objects.all():
        floor = slot.floor_number
        if floor not in slots_by_floor:
            slots_by_floor[floor] = {'available': [], 'booked': [], 'maintenance': []}
        slots_by_floor[floor][slot.status].append(slot)
    
    context = {
        'available_slots': available_slots,
        'booked_slots': booked_slots,
        'maintenance_slots': maintenance_slots,
        'active_booking': active_booking,
        'recent_bookings': recent_bookings,
        'slots_by_floor': slots_by_floor,
    }
    return render(request, 'parking/user/dashboard.html', context)


# Admin Views - Slot Administration
@login_required
@user_passes_test(is_admin)
def slot_list(request):
    slots = ParkingSlot.objects.all()
    return render(request, 'parking/admin/slot_list.html', {'slots': slots})


@login_required
@user_passes_test(is_admin)
def slot_create(request):
    if request.method == 'POST':
        form = ParkingSlotForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Parking slot created successfully!')
            return redirect('slot_list')
    else:
        form = ParkingSlotForm()
    return render(request, 'parking/admin/slot_form.html', {'form': form, 'title': 'Add Parking Slot'})


@login_required
@user_passes_test(is_admin)
def slot_edit(request, pk):
    slot = get_object_or_404(ParkingSlot, pk=pk)
    if request.method == 'POST':
        form = ParkingSlotForm(request.POST, instance=slot)
        if form.is_valid():
            form.save()
            messages.success(request, 'Parking slot updated successfully!')
            return redirect('slot_list')
    else:
        form = ParkingSlotForm(instance=slot)
    return render(request, 'parking/admin/slot_form.html', {'form': form, 'slot': slot, 'title': 'Edit Parking Slot'})


@login_required
@user_passes_test(is_admin)
def slot_delete(request, pk):
    slot = get_object_or_404(ParkingSlot, pk=pk)
    if request.method == 'POST':
        slot.delete()
        messages.success(request, 'Parking slot deleted successfully!')
        return redirect('slot_list')
    return render(request, 'parking/admin/slot_delete.html', {'slot': slot})




# Admin Views - Pricing Configuration
@login_required
@user_passes_test(is_admin)
def pricing_manage(request):
    pricing = Pricing.get_current_pricing()
    if request.method == 'POST':
        form = PricingForm(request.POST, instance=pricing)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pricing updated successfully!')
            return redirect('pricing_manage')
    else:
        form = PricingForm(instance=pricing)
    return render(request, 'parking/admin/pricing_manage.html', {'form': form, 'pricing': pricing})


# Admin Views - User Administration
@login_required
@user_passes_test(is_admin)
def user_list(request):
    users = User.objects.all()
    search = request.GET.get('search', '')
    if search:
        users = users.filter(Q(username__icontains=search) | Q(email__icontains=search))
    return render(request, 'parking/admin/user_list.html', {'users': users, 'search': search})


@login_required
@user_passes_test(is_admin)
def user_create(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Send registration email
            try:
                send_user_registration_email(user)
            except Exception as e:
                print(f"Error sending registration email: {e}")
            messages.success(request, 'User created successfully!')
            return redirect('user_list')
    else:
        form = UserRegistrationForm()
    return render(request, 'parking/admin/user_form.html', {'form': form, 'title': 'Create User'})


@login_required
@user_passes_test(is_admin)
def user_delete(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.user == user:
        messages.error(request, 'You cannot delete your own account!')
        return redirect('user_list')
    if request.method == 'POST':
        user.delete()
        messages.success(request, 'User deleted successfully!')
        return redirect('user_list')
    return render(request, 'parking/admin/user_delete.html', {'user': user})


# Admin Views - Booking Overview
@login_required
@user_passes_test(is_admin)
def booking_list(request):
    bookings = Booking.objects.all()
    
    # Filters
    status_filter = request.GET.get('status', '')
    date_filter = request.GET.get('date', '')
    
    if status_filter:
        bookings = bookings.filter(status=status_filter)
    if date_filter:
        bookings = bookings.filter(start_time__date=date_filter)
    
    return render(request, 'parking/admin/booking_list.html', {
        'bookings': bookings,
        'status_filter': status_filter,
        'date_filter': date_filter,
        'is_active': status_filter == 'active',
        'is_completed': status_filter == 'completed',
        'is_cancelled': status_filter == 'cancelled',
    })


@login_required
@user_passes_test(is_admin)
def booking_force_checkout(request, pk):
    """Force checkout a booking"""
    booking = get_object_or_404(Booking, pk=pk)
    if request.method == 'POST':
        booking.checkout(payment_method='cash')
        messages.success(request, 'Booking checked out successfully! Email notification sent to user.')
        return redirect('booking_list')
    return render(request, 'parking/admin/booking_force_checkout.html', {'booking': booking})


@login_required
@user_passes_test(is_admin)
def admin_booking_detail(request, pk):
    """Admin view for booking details (similar to user side)"""
    booking = get_object_or_404(Booking, pk=pk)
    return render(request, 'parking/user/booking_detail.html', {'booking': booking, 'is_admin_view': True})


@login_required
@user_passes_test(is_admin)
def admin_complete_checkout(request):
    """Complete checkout after admin verification"""
    if request.method == 'POST':
        booking_id = request.POST.get('booking_id')
        payment_method = request.POST.get('payment_method', 'cash')
        transaction_id = request.POST.get('transaction_id', '')
        
        if payment_method.lower() == 'undefined':
            payment_method = 'cash'
        if transaction_id.lower() == 'undefined':
            transaction_id = ''
        
        try:
            booking = Booking.objects.get(id=booking_id, status='active')
            
            # Create payment record
            Payment.objects.create(
                booking=booking,
                user=booking.user,
                amount=booking.total_price if booking.total_price else 0,
                payment_method=payment_method,
                payment_status='completed',
                payment_date=timezone.now(),
                transaction_id=transaction_id or f"TXN-{booking.id}-{timezone.now().strftime('%Y%m%d%H%M%S')}",
            )
            
            # Complete checkout and send email notification
            booking.checkout(payment_method=payment_method)
            
            return JsonResponse({
                'success': True,
                'message': 'Checkout completed successfully! Email notification sent to user.'
            })
        except Booking.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Booking not found'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error: {str(e)}'
            })
    return JsonResponse({'success': False, 'message': 'Invalid request'})


@login_required
@user_passes_test(is_admin)
def admin_pass_key_verify(request):
    """Admin view to verify pass key for check-in or check-out"""
    if request.method == 'POST':
        pass_key = request.POST.get('pass_key', '').strip().upper()
        action = request.POST.get('action', 'checkout')  # 'checkin' or 'checkout'
        
        try:
            booking = Booking.objects.get(pass_key=pass_key)
            
            if action == 'checkin':
                # Handle check-in
                if booking.entry_status == 'pending' and booking.status == 'active':
                    booking.entry_status = 'entered'
                    booking.entry_time = timezone.now()
                    booking.save()
                    
                    # Send check-in email notification
                    try:
                        send_checkin_notification(booking)
                    except Exception as e:
                        print(f"Error sending check-in email: {e}")
                    
                    # Use actual entry time (current time) for display
                    display_entry_time = timezone.localtime(booking.entry_time)
                    
                    return JsonResponse({
                        'success': True,
                        'action': 'checkin',
                        'message': 'Check-in confirmed successfully!',
                        'booking': {
                            'id': booking.id,
                            'slot': booking.slot.slot_number,
                            'vehicle': booking.vehicle_number,
                            'user': booking.user.username,
                            'entry_time': display_entry_time.strftime('%Y-%m-%d %I:%M %p'),
                        }
                    })
                else:
                    return JsonResponse({
                        'success': False,
                        'message': 'Booking already checked in or not active'
                    })
            else:
                # Handle check-out
                # Allow checkout if status is active.
                if booking.status == 'active':
                    # Calculate price before checkout
                    booking.calculate_price()
                    
                    # Use actual entry time and current time for display
                    display_entry_time = timezone.localtime(booking.entry_time) if booking.entry_time else timezone.localtime(booking.start_time)
                    display_checkout_time = timezone.localtime(timezone.now())
                    
                    return JsonResponse({
                        'success': True,
                        'action': 'checkout',
                        'booking': {
                            'id': booking.id,
                            'slot': booking.slot.slot_number,
                            'vehicle': booking.vehicle_number,
                            'user': booking.user.username,
                            'entry_time': display_entry_time.strftime('%Y-%m-%d %I:%M %p'),
                            'checkout_time': display_checkout_time.strftime('%Y-%m-%d %I:%M %p'),
                            'total_price': str(booking.total_price) if booking.total_price else '0.00',
                            'total_hours': str(booking.total_hours) if booking.total_hours else '0',
                        }
                    })
                else:
                    return JsonResponse({
                        'success': False,
                        'message': 'Booking not active'
                    })
        except Booking.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Invalid pass key or booking not found'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request'})


@login_required
@user_passes_test(is_admin)
def admin_checkout_verify(request):
    """Admin checkout verification page"""
    return render(request, 'parking/admin/checkout_verify.html')


# User Views - Booking
@login_required
def book_slot(request):
    # Get all slots with their status
    all_slots = ParkingSlot.objects.all().order_by('floor_number', 'slot_number')
    available_slots = ParkingSlot.objects.filter(status='available')
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            # Check if user has an active booking
            active_booking = Booking.objects.filter(user=request.user, status='active').first()
            if active_booking:
                messages.error(request, 'You already have an active booking!')
                return redirect('dashboard')
            
            slot = form.cleaned_data['slot']
            start_time = form.cleaned_data['start_time']
            end_time = form.cleaned_data['end_time']
            
            # Check if slot is available
            if slot.status != 'available':
                messages.error(request, f'Slot {slot.slot_number} is not available! Current status: {slot.get_status_display()}')
                form.fields['slot'].queryset = all_slots
                pricing = Pricing.get_current_pricing()
                vehicle_categories = VehicleCategory.objects.all()
                return render(request, 'parking/user/book_slot.html', {
                    'form': form, 
                    'available_slots': available_slots,
                    'all_slots': all_slots,
                    'pricing': pricing,
                    'vehicle_categories': vehicle_categories,
                })
            
            # Check for slot conflicts (if slot is booked during the requested time)
            conflicting_bookings = Booking.objects.filter(
                slot=slot,
                status='active',
                start_time__lt=end_time,
                end_time__gt=start_time
            ).exists()
            
            if conflicting_bookings:
                messages.error(request, f'Slot {slot.slot_number} is already booked during the selected time period!')
                form.fields['slot'].queryset = all_slots
                pricing = Pricing.get_current_pricing()
                vehicle_categories = VehicleCategory.objects.all()
                return render(request, 'parking/user/book_slot.html', {
                    'form': form, 
                    'available_slots': available_slots,
                    'all_slots': all_slots,
                    'pricing': pricing,
                    'vehicle_categories': vehicle_categories,
                })
            
            booking = form.save(commit=False)
            booking.user = request.user
            booking.start_time = start_time
            booking.end_time = end_time
            
            # Generate pass key
            booking.generate_pass_key()
            booking.save()
            
            # Update slot status
            slot.status = 'booked'
            slot.save()
            
            # Send booking confirmation notification with pass key
            send_booking_confirmation(booking)
            
            messages.success(request, f'Slot {slot.slot_number} booked successfully from {start_time.strftime("%Y-%m-%d %I:%M %p")} to {end_time.strftime("%Y-%m-%d %I:%M %p")}! Pass key sent to your email.')
            return redirect('booking_detail', booking_id=booking.id)
    else:
        form = BookingForm()
        form.fields['slot'].queryset = all_slots
    
    pricing = Pricing.get_current_pricing()
    vehicle_categories = VehicleCategory.objects.all()
    return render(request, 'parking/user/book_slot.html', {
        'form': form, 
        'available_slots': available_slots,
        'all_slots': all_slots,
        'pricing': pricing,
        'vehicle_categories': vehicle_categories,
    })


@login_required
def checkout(request, booking_id):
    """Redirect to pass key entry for checkout"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user, status='active')
    return redirect('checkout_pass_key', booking_id=booking_id)


@login_required
def booking_history(request):
    bookings = Booking.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'parking/user/booking_history.html', {'bookings': bookings})


@login_required
def booking_detail(request, booking_id):
    """View booking details with pass key"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    
    # Handle booking cancellation
    if request.method == 'POST' and request.POST.get('action') == 'cancel':
        # Allow cancel only for active bookings that have not yet entered
        if booking.status == 'active' and booking.entry_status == 'pending':
            booking.status = 'cancelled'
            booking.updated_at = timezone.now()
            booking.save()
            
            # Release slot
            booking.slot.status = 'available'
            booking.slot.save()
            
            # Send cancellation notification/email
            try:
                send_booking_cancellation(booking)
            except Exception:
                pass
            
            messages.success(request, 'Your booking has been cancelled successfully.')
        else:
            messages.error(request, 'This booking cannot be cancelled. It may already be in progress or completed.')
        return redirect('booking_history')
    
    # Generate pass key if not exists
    if not booking.pass_key:
        booking.generate_pass_key()
    
    return render(request, 'parking/user/booking_detail.html', {'booking': booking})


@login_required
def booking_pass_key(request, booking_id):
    """Display pass key for booking"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    
    # Generate pass key if not exists
    if not booking.pass_key:
        booking.generate_pass_key()
    
    return JsonResponse({
        'pass_key': booking.pass_key,
        'booking_id': booking.id
    })


@login_required
def booking_invoice_pdf(request, booking_id):
    """Generate PDF invoice for completed booking"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    
    if booking.status != 'completed':
        messages.error(request, 'Invoice is only available for completed bookings.')
        return redirect('booking_history')
    
    # Generate PDF using utility function
    pdf = generate_pdf_invoice(booking)
    
    # Create HTTP response
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="invoice_{booking.id}.pdf"'
    
    return response


# Legacy QR Code Scanning Views (deprecated - kept for backward compatibility)
# These views are no longer used but kept to avoid breaking existing links
@login_required
def user_qr_scan_entry(request):
    """User QR code scanning page for entry (deprecated - use pass key instead)"""
    return redirect('dashboard')


@login_required
def user_qr_scan_exit(request):
    """User QR code scanning page for exit (deprecated - use pass key instead)"""
    return redirect('dashboard')


@login_required
def user_pass_key_verify(request):
    """Verify pass key and process entry/exit for users"""
    if request.method == 'POST':
        pass_key = request.POST.get('pass_key', '').strip().upper()
        action = request.POST.get('action', 'entry')  # 'entry' or 'exit'
        
        try:
            booking = Booking.objects.get(pass_key=pass_key, user=request.user)
            
            if action == 'entry':
                if booking.entry_status == 'pending':
                    booking.entry_status = 'entered'
                    booking.entry_time = timezone.now()
                    booking.save()
                    return JsonResponse({
                        'success': True,
                        'message': f'Entry confirmed for Booking {booking.id}',
                        'booking': {
                            'id': booking.id,
                            'slot': booking.slot.slot_number,
                            'vehicle': booking.vehicle_number,
                        }
                    })
                else:
                    return JsonResponse({
                        'success': False,
                        'message': 'Booking already entered or completed'
                    })
            else:  # exit
                if booking.entry_status == 'entered' and booking.status == 'active':
                    # Don't checkout yet, just confirm exit
                    booking.entry_status = 'exited'
                    booking.exit_time = timezone.now()
                    booking.save()
                    return JsonResponse({
                        'success': True,
                        'message': f'Exit confirmed. Proceed to payment.',
                        'booking_id': booking.id,
                        'redirect': f'/checkout/{booking.id}/payment/'
                    })
                else:
                    return JsonResponse({
                        'success': False,
                        'message': 'Booking not active or not entered'
                    })
        except Booking.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Invalid pass key'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request'})


@login_required
def booking_pass_key_display(request, booking_id):
    """Display pass key for booking"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    
    # Generate pass key if not exists
    if not booking.pass_key:
        booking.generate_pass_key()
    
    return render(request, 'parking/user/pass_key_display.html', {'booking': booking})


@login_required
def checkout_pass_key(request, booking_id):
    """Pass key entry page for checkout"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user, status='active')
    return render(request, 'parking/user/checkout_pass_key.html', {'booking': booking})


@login_required
def checkout_payment(request, booking_id):
    """Payment page after QR scan exit"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user, status='active')
    
    # Calculate price based on actual usage time
    booking.calculate_price()
    estimated_price = booking.total_price if booking.total_price else Decimal('0.00')
    estimated_hours = booking.total_hours if booking.total_hours else Decimal('0.00')
    
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'cash')
        
        # Create payment record first
        payment = Payment.objects.create(
            booking=booking,
            user=request.user,
            amount=booking.total_price,
            payment_method=payment_method,
            payment_status='completed',
            payment_date=timezone.now(),
            transaction_id=f"TXN-{booking.id}-{timezone.now().strftime('%Y%m%d%H%M%S')}",
        )
        
        # Complete checkout and send email (only after payment confirmation)
        booking.checkout(payment_method=payment_method)
        
        messages.success(request, f'Payment successful! Amount: Rs.{booking.total_price:.2f}. Invoice sent to your email.')
        return redirect('booking_history')
    
    context = {
        'booking': booking,
        'estimated_price': estimated_price,
        'estimated_hours': estimated_hours,
    }
    return render(request, 'parking/user/checkout_payment.html', context)


# Payment Views
@login_required
def process_payment(request, booking_id):
    """Process payment for a booking"""
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'stripe')
        amount = booking.total_price if booking.total_price else 0
        
        # In a real implementation, integrate with Stripe/PayPal API here
        # For now, we'll simulate payment processing
        payment = Payment.objects.create(
            booking=booking,
            user=request.user,
            amount=amount,
            payment_method=payment_method,
            payment_status='completed',
            payment_date=timezone.now(),
            transaction_id=f"TXN-{booking.id}-{timezone.now().strftime('%Y%m%d%H%M%S')}",
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Payment processed successfully',
            'payment_id': payment.id,
            'transaction_id': payment.transaction_id,
        })
    
    return JsonResponse({'success': False, 'message': 'Invalid request'})


# Theme Views
def set_theme(request):
    """Set theme preference"""
    if request.method == 'POST':
        theme = request.POST.get('theme', 'light')
        request.session['theme'] = theme
        return JsonResponse({'success': True, 'theme': theme})
    return JsonResponse({'success': False})


# AJAX Views
@login_required
def get_slot_status(request):
    """Get real-time slot status via AJAX"""
    slots = ParkingSlot.objects.all()
    data = {
        'available': slots.filter(status='available').count(),
        'booked': slots.filter(status='booked').count(),
        'maintenance': slots.filter(status='maintenance').count(),
        'slots': [
            {
                'id': slot.id,
                'slot_number': slot.slot_number,
                'floor_number': slot.floor_number,
                'status': slot.status
            }
            for slot in slots
        ]
    }
    return JsonResponse(data)


