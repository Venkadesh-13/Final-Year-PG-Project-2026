"""
Utility functions for pass key generation, PDF invoices, and email notifications
"""
import qrcode
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.mail import EmailMessage, send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.http import HttpResponse
from django.utils import timezone
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT


def generate_qr_code_image(booking):
    """Generate QR code image for a booking"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    
    # QR code data contains booking ID and QR code hash
    qr_data = f"BOOKING:{booking.id}:{booking.qr_code}"
    qr.add_data(qr_data)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to bytes
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    return buffer.getvalue()


def generate_pdf_invoice(booking):
    """Generate PDF invoice for a booking"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    
    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#2563eb'),
        spaceAfter=30,
        alignment=TA_CENTER,
    )
    
    # Title
    elements.append(Paragraph("PARKING INVOICE", title_style))
    elements.append(Spacer(1, 0.3*inch))
    
    # Fetch payment details
    payment = booking.payments.filter(payment_status='completed').last()
    payment_method = 'N/A'
    transaction_id = 'N/A'
    if payment:
        from .models import Payment
        # Robust check for "undefined" string sent from frontend
        method_val = payment.payment_method
        if method_val and method_val.lower() != 'undefined':
            payment_method = dict(Payment.PAYMENT_METHOD_CHOICES).get(method_val, method_val.title())
        
        txn_val = payment.transaction_id
        if txn_val and txn_val.lower() != 'undefined':
            transaction_id = txn_val
        else:
            transaction_id = 'N/A'

    # Company Info
    def format_time_12h_pdf(dt):
        if dt:
            # Ensure time is localized to IST
            localized_dt = timezone.localtime(dt)
            return localized_dt.strftime('%Y-%m-%d %I:%M %p')
        return 'N/A'
    
    company_info = [
        ["Parking Booking System"],
        ["Invoice " + str(booking.id)],
        ["Date: " + (format_time_12h_pdf(booking.exit_time or booking.end_time or timezone.now()))],
    ]
    company_table = Table(company_info, colWidths=[6*inch])
    company_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (0, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (0, 0), 14),
    ]))
    elements.append(company_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Customer Info
    customer_data = [
        ['Customer Name:', booking.driver_name or booking.user.username],
        ['Email:', booking.driver_email or booking.user.email or 'N/A'],
        ['Phone:', booking.driver_phone or booking.user.phone or 'N/A'],
    ]
    customer_table = Table(customer_data, colWidths=[2*inch, 4*inch])
    customer_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(customer_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Booking Details
    # Use start_time and end_time (or exit_time) as requested for consistency
    booking_data = [
        ['Parking Slot:', f"{booking.slot.slot_number} (Floor {booking.slot.floor_number})"],
        ['Vehicle Number:', booking.vehicle_number],
        ['Vehicle Category:', booking.vehicle_category.get_name_display() if booking.vehicle_category else 'Standard'],
        ['Vehicle Make/Model:', f"{booking.vehicle_make} {booking.vehicle_model}".strip() or 'N/A'],
        ['Check-In Time:', format_time_12h_pdf(booking.entry_time or booking.start_time)],
        ['Check-Out Time:', format_time_12h_pdf(booking.exit_time or booking.end_time)],
        ['Duration:', f"{booking.total_hours} hours" if booking.total_hours else 'N/A'],
    ]
    booking_table = Table(booking_data, colWidths=[2*inch, 4*inch])
    booking_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(booking_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Payment Details Section
    payment_data = [
        ['Payment Mode:', payment_method],
        ['Transaction ID:', transaction_id],
        ['Payment Status:', 'Completed'],
    ]
    payment_table = Table(payment_data, colWidths=[2*inch, 4*inch])
    payment_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TEXTCOLOR', (1, 2), (1, 2), colors.green),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(payment_table)
    elements.append(Spacer(1, 0.3*inch))

    # Pricing Details
    total_price = booking.total_price if booking.total_price else 0
    pricing_data = [
        ['Description', 'Amount'],
        ['Parking Fee', f"Rs.{total_price:.2f}"],
        ['', ''],
        ['TOTAL', f"Rs.{total_price:.2f}"],
    ]
    pricing_table = Table(pricing_data, colWidths=[4*inch, 2*inch])
    pricing_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('FONTSIZE', (0, -1), (-1, -1), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -2), 1, colors.black),
        ('LINEBELOW', (0, -1), (-1, -1), 2, colors.black),
    ]))
    elements.append(pricing_table)
    elements.append(Spacer(1, 0.3*inch))

    # Footer
    footer = Paragraph("Thank you for using Parking Booking System!", styles['Normal'])
    elements.append(footer)
    
    # Build PDF
    doc.build(elements)
    pdf = buffer.getvalue()
    buffer.close()
    return pdf


def send_booking_confirmation(booking):
    """Send booking confirmation notification with pass key"""
    from .models import Notification
    
    # Generate pass key if not exists
    if not booking.pass_key:
        booking.generate_pass_key()
    
    notification = Notification.objects.create(
        booking=booking,
        user=booking.user,
        notification_type='booking_confirmation',
        title=f'Booking Confirmed - Slot {booking.slot.slot_number}',
        message=f'Your parking booking for slot {booking.slot.slot_number} has been confirmed. Vehicle: {booking.vehicle_number}. Your pass key is {booking.pass_key}.',
    )
    
    # Send email if email is provided
    if booking.driver_email or booking.user.email:
        email = booking.driver_email or booking.user.email
        try:
            subject = f'Parking Booking Confirmed - Slot {booking.slot.slot_number}'
            
            # HTML email body
            html_message = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2 style="color: #2563eb;">Parking Booking Confirmed!</h2>
                    <p>Dear {booking.driver_name or booking.user.username},</p>
                    <p>Your parking booking has been confirmed!</p>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Booking Details:</h3>
                        <p><strong>Slot:</strong> {booking.slot.slot_number} (Floor {booking.slot.floor_number})</p>
                        <p><strong>Vehicle:</strong> {booking.vehicle_number}</p>
                        <p><strong>Scheduled Check-In:</strong> {timezone.localtime(booking.start_time).strftime('%Y-%m-%d %I:%M %p')}</p>
                        <p><strong>Scheduled Check-Out:</strong> {timezone.localtime(booking.end_time).strftime('%Y-%m-%d %I:%M %p') if booking.end_time else 'Not set'}</p>
                        <p><strong>Booking ID:</strong> {booking.id}</p>
                    </div>
                    
                    <div style="background: #e0f2fe; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; border: 2px solid #2563eb;">
                        <h3 style="margin-top: 0; color: #2563eb;">Your Pass Key</h3>
                        <p style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #1e40af; margin: 10px 0;">{booking.pass_key}</p>
                        <p style="color: #666; font-size: 14px;">Please provide this pass key at the entry gate and during checkout</p>
                    </div>
                    
                    <p>Please keep this pass key safe. You will need it for entry and checkout verification.</p>
                    <p>Thank you for using Parking Booking System!</p>
                </div>
            </body>
            </html>
            """
            
            # Plain text fallback
            plain_message = f"""
Dear {booking.driver_name or booking.user.username},

Your parking booking has been confirmed!

Booking Details:
- Slot: {booking.slot.slot_number} (Floor {booking.slot.floor_number})
- Vehicle: {booking.vehicle_number}
- Scheduled Check-In: {timezone.localtime(booking.start_time).strftime('%Y-%m-%d %I:%M %p')}
- Scheduled Check-Out: {timezone.localtime(booking.end_time).strftime('%Y-%m-%d %I:%M %p') if booking.end_time else 'Not set'}
- Booking ID: {booking.id}

Your Pass Key: {booking.pass_key}

Please keep this pass key safe. You will need it for entry and checkout verification.

Thank you for using Parking Booking System!
"""
            
            recipient_list = [email]
            
            # Create email message
            email_msg = EmailMessage(
                subject,
                plain_message,
                settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@smartparking.com',
                recipient_list,
            )
            email_msg.content_subtype = "html"
            email_msg.body = html_message
            email_msg.send()
            
            notification.email_sent = True
            notification.save()
        except Exception as e:
            print(f"Error sending email: {e}")


def send_checkout_notification(booking, payment_method='cash'):
    """Send checkout summary notification with PDF invoice"""
    from .models import Notification, Payment
    
    # Ensure price is calculated
    if not booking.total_price:
        booking.calculate_price()
    
    # Get payment method display name
    payment_method_display = dict(Payment.PAYMENT_METHOD_CHOICES).get(payment_method, payment_method.title())
    
    # Calculate actual usage hours
    if booking.entry_time and booking.exit_time:
        duration = booking.exit_time - booking.entry_time
        actual_hours = duration.total_seconds() / 3600
    elif booking.entry_time:
        duration = timezone.now() - booking.entry_time
        actual_hours = duration.total_seconds() / 3600
    else:
        actual_hours = booking.total_hours if booking.total_hours else 0
    
    notification = Notification.objects.create(
        booking=booking,
        user=booking.user,
        notification_type='checkout_summary',
        title=f'Checkout Complete - Slot {booking.slot.slot_number}',
        message=f'Your parking session has ended. Total: Rs.{booking.total_price:.2f} for {booking.total_hours} hours. Payment method: {payment_method_display}. Invoice available in booking history.',
    )
    
    # Send email if email is provided
    if booking.driver_email or booking.user.email:
        email = booking.driver_email or booking.user.email
        try:
            subject = f'Parking Checkout Summary - Slot {booking.slot.slot_number}'
            
            # Format time in 12-hour format with local timezone
            def format_time_12h(dt):
                if dt:
                    localized_dt = timezone.localtime(dt)
                    return localized_dt.strftime('%Y-%m-%d %I:%M %p')
                return 'N/A'
            
            # Use actual times if available, otherwise booked times
            checkin_time = format_time_12h(booking.entry_time or booking.start_time)
            checkout_time = format_time_12h(booking.exit_time or booking.end_time)
            
            # Robust transaction ID fetching
            payment_record = booking.payments.filter(payment_status='completed').last()
            txn_id = 'N/A'
            if payment_record and payment_record.transaction_id and payment_record.transaction_id.lower() != 'undefined':
                txn_id = payment_record.transaction_id

            # HTML email body
            html_message = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2 style="color: #2563eb;">Parking Session Completed!</h2>
                    <p>Dear {booking.driver_name or booking.user.username},</p>
                    <p>Your parking session has been completed!</p>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Checkout Summary:</h3>
                        <p><strong>Booking ID:</strong> {booking.id}</p>
                        <p><strong>Slot:</strong> {booking.slot.slot_number} (Floor {booking.slot.floor_number})</p>
                        <p><strong>Vehicle:</strong> {booking.vehicle_number}</p>
                        <p><strong>Check-In Time:</strong> {checkin_time}</p>
                        <p><strong>Check-Out Time:</strong> {checkout_time}</p>
                        <hr style="margin: 15px 0; border: none; border-top: 1px solid #e5e7eb;">
                        <p><strong>Used Hours:</strong> {booking.total_hours} hours</p>
                        <p><strong>Payment Method:</strong> {payment_method_display}</p>
                        <p><strong>Transaction ID:</strong> {txn_id}</p>
                        <p><strong>Paid Amount:</strong> <span style="font-size: 18px; color: #10b981; font-weight: bold;">Rs.{booking.total_price:.2f}</span></p>
                    </div>
                    
                    <p>Please find your invoice attached to this email.</p>
                    <p>Thank you for using Parking Booking System!</p>
                </div>
            </body>
            </html>
            """
            
            # Plain text fallback
            plain_message = f"""
Dear {booking.driver_name or booking.user.username},

Your parking session has been completed!

Checkout Summary:
- Booking ID: {booking.id}
- Slot: {booking.slot.slot_number} (Floor {booking.slot.floor_number})
- Vehicle: {booking.vehicle_number}
- Check-In Time: {checkin_time}
- Check-Out Time: {checkout_time}

Used Hours: {booking.total_hours} hours
Payment Method: {payment_method_display}
Transaction ID: {txn_id}
Paid Amount: Rs.{booking.total_price:.2f}

Please find your invoice attached to this email.

Thank you for using Parking Booking System!
"""
            
            # Generate PDF invoice
            pdf_invoice = generate_pdf_invoice(booking)
            
            recipient_list = [email]
            
            # Create email message with PDF attachment
            email_msg = EmailMessage(
                subject,
                plain_message,
                settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@smartparking.com',
                recipient_list,
            )
            email_msg.content_subtype = "html"
            email_msg.body = html_message
            email_msg.attach(f'invoice_{booking.id}.pdf', pdf_invoice, 'application/pdf')
            email_msg.send()
            
            notification.email_sent = True
            notification.save()
        except Exception as e:
            print(f"Error sending email: {e}")


def send_user_registration_email(user):
    """Send welcome email to newly registered user"""
    if user.email:
        try:
            subject = 'Welcome to Parking Booking System!'
            
            html_message = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2 style="color: #2563eb;">Welcome to Parking Booking System!</h2>
                    <p>Dear {user.username},</p>
                    <p>Thank you for registering with our parking booking system!</p>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Your Account Details:</h3>
                        <p><strong>Username:</strong> {user.username}</p>
                        <p><strong>Email:</strong> {user.email}</p>
                        <p><strong>Role:</strong> {user.get_role_display()}</p>
                    </div>
                    
                    <p>You can now start booking parking slots through our system.</p>
                    <p>If you have any questions, please don't hesitate to contact our support team.</p>
                    <p>Thank you for choosing Parking Booking System!</p>
                </div>
            </body>
            </html>
            """
            
            plain_message = f"""
Dear {user.username},

Thank you for registering with our parking booking system!

Your Account Details:
- Username: {user.username}
- Email: {user.email}
- Role: {user.get_role_display()}

You can now start booking parking slots through our system.

If you have any questions, please don't hesitate to contact our support team.

Thank you for choosing Parking Booking System!
"""
            
            recipient_list = [user.email]
            email_msg = EmailMessage(
                subject,
                plain_message,
                settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@smartparking.com',
                recipient_list,
            )
            email_msg.content_subtype = "html"
            email_msg.body = html_message
            email_msg.send()
        except Exception as e:
            print(f"Error sending registration email: {e}")


def send_checkin_notification(booking):
    """Send check-in confirmation email to user"""
    from .models import Notification
    
    notification = Notification.objects.create(
        booking=booking,
        user=booking.user,
        notification_type='entry_confirmed',
        title=f'Check-In Confirmed - Slot {booking.slot.slot_number}',
        message=f'You have successfully checked in to slot {booking.slot.slot_number}. Check-In time: {timezone.localtime(booking.entry_time or booking.start_time).strftime("%Y-%m-%d %I:%M %p")}.',
    )
    
    # Send email if email is provided
    if booking.driver_email or booking.user.email:
        email = booking.driver_email or booking.user.email
        try:
            subject = f'Check-In Confirmed - Slot {booking.slot.slot_number}'
            
            html_message = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2 style="color: #10b981;">Check-In Confirmed!</h2>
                    <p>Dear {booking.driver_name or booking.user.username},</p>
                    <p>Your check-in has been confirmed successfully!</p>
                    
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Check-In Details:</h3>
                        <p><strong>Booking ID:</strong> {booking.id}</p>
                        <p><strong>Slot:</strong> {booking.slot.slot_number} (Floor {booking.slot.floor_number})</p>
                        <p><strong>Vehicle:</strong> {booking.vehicle_number}</p>
                        <p><strong>Check-In Time:</strong> {timezone.localtime(booking.entry_time or booking.start_time).strftime('%Y-%m-%d %I:%M %p')}</p>
                        <p><strong>Pass Key:</strong> {booking.pass_key}</p>
                    </div>
                    
                    <p>You are now checked in. Please keep your pass key safe for checkout.</p>
                    <p>Thank you for using Parking Booking System!</p>
                </div>
            </body>
            </html>
            """
            
            plain_message = f"""
Dear {booking.driver_name or booking.user.username},

Your check-in has been confirmed successfully!

Check-In Details:
- Booking ID: {booking.id}
- Slot: {booking.slot.slot_number} (Floor {booking.slot.floor_number})
- Vehicle: {booking.vehicle_number}
- Check-In Time: {timezone.localtime(booking.entry_time or booking.start_time).strftime('%Y-%m-%d %I:%M %p')}
- Pass Key: {booking.pass_key}

You are now checked in. Please keep your pass key safe for checkout.

Thank you for using Parking Booking System!
"""
            
            recipient_list = [email]
            email_msg = EmailMessage(
                subject,
                plain_message,
                settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@smartparking.com',
                recipient_list,
            )
            email_msg.content_subtype = "html"
            email_msg.body = html_message
            email_msg.send()
            
            notification.email_sent = True
            notification.save()
        except Exception as e:
            print(f"Error sending check-in email: {e}")


def send_booking_cancellation(booking):
    """Send booking cancellation notification and email"""
    from .models import Notification
    
    notification = Notification.objects.create(
        booking=booking,
        user=booking.user,
        notification_type='booking_cancelled',
        title=f'Booking Cancelled - Slot {booking.slot.slot_number}',
        message=f'Your parking booking for slot {booking.slot.slot_number} (Booking ID: {booking.id}) has been cancelled.',
    )
    
    # Send email if email is provided
    if booking.driver_email or booking.user.email:
        email = booking.driver_email or booking.user.email
        try:
            subject = f'Parking Booking Cancelled - Slot {booking.slot.slot_number}'
            
            html_message = f"""
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    <h2 style="color: #dc2626;">Parking Booking Cancelled</h2>
                    <p>Dear {booking.driver_name or booking.user.username},</p>
                    <p>Your parking booking has been cancelled.</p>
                    <div style="background: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <h3 style="margin-top: 0;">Booking Details:</h3>
                        <p><strong>Booking ID:</strong> {booking.id}</p>
                        <p><strong>Slot:</strong> {booking.slot.slot_number} (Floor {booking.slot.floor_number})</p>
                        <p><strong>Vehicle:</strong> {booking.vehicle_number}</p>
                    </div>
                    <p>If this was not done by you, please contact support.</p>
                    <p>Thank you for using Parking Booking System!</p>
                </div>
            </body>
            </html>
            """
            
            plain_message = f"""
Dear {booking.driver_name or booking.user.username},

Your parking booking has been cancelled.

Booking Details:
- Booking ID: {booking.id}
- Slot: {booking.slot.slot_number} (Floor {booking.slot.floor_number})
- Vehicle: {booking.vehicle_number}

If this was not done by you, please contact support.

Thank you for using Parking Booking System!
"""
            recipient_list = [email]
            email_msg = EmailMessage(
                subject,
                plain_message,
                settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@smartparking.com',
                recipient_list,
            )
            email_msg.content_subtype = "html"
            email_msg.body = html_message
            email_msg.send()
            
            notification.email_sent = True
            notification.save()
        except Exception as e:
            print(f"Error sending cancellation email: {e}")
