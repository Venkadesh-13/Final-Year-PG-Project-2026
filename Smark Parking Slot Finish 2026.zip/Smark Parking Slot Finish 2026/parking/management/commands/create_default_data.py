"""
Management command to create default vehicle categories
"""
from django.core.management.base import BaseCommand
from parking.models import VehicleCategory


class Command(BaseCommand):
    help = 'Creates default vehicle categories'

    def handle(self, *args, **options):
        categories = [
            {'name': 'car', 'description': 'Standard car', 'multiplier': 1.00},
            {'name': 'motorcycle', 'description': 'Motorcycle or scooter', 'multiplier': 0.75},
            {'name': 'suv', 'description': 'SUV or large vehicle', 'multiplier': 1.25},
            {'name': 'van', 'description': 'Van or minivan', 'multiplier': 1.50},
            {'name': 'truck', 'description': 'Truck or commercial vehicle', 'multiplier': 2.00},
            {'name': 'bicycle', 'description': 'Bicycle', 'multiplier': 0.50},
        ]
        
        created_count = 0
        for cat_data in categories:
            category, created = VehicleCategory.objects.get_or_create(
                name=cat_data['name'],
                defaults={
                    'description': cat_data['description'],
                    'multiplier': cat_data['multiplier']
                }
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'Created vehicle category: {category.get_name_display()}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Vehicle category already exists: {category.get_name_display()}')
                )
        
        self.stdout.write(
            self.style.SUCCESS(f'\nSuccessfully created {created_count} vehicle categories!')
        )

