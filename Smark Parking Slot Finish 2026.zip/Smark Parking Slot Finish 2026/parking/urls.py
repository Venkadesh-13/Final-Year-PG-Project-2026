from django.urls import path
from django.contrib.auth import views as auth_views
from . import views



    

urlpatterns = [
    # Authentication
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Admin Views - Slot Administration
    path('admin/slot-administration/', views.slot_list, name='slot_list'),
    path('admin/slot-administration/create/', views.slot_create, name='slot_create'),
    path('admin/slot-administration/<int:pk>/edit/', views.slot_edit, name='slot_edit'),
    path('admin/slot-administration/<int:pk>/delete/', views.slot_delete, name='slot_delete'),
    

    # Admin Views - Pricing Configuration
    path('admin/pricing-configuration/', views.pricing_manage, name='pricing_manage'),
    
    # Admin Views - User Administration
    path('admin/user-administration/', views.user_list, name='user_list'),
    path('admin/user-administration/create/', views.user_create, name='user_create'),
    path('admin/user-administration/<int:pk>/delete/', views.user_delete, name='user_delete'),
    
    # Admin Views - Booking Overview
    path('admin/booking-overview/', views.booking_list, name='booking_list'),
    path('admin/booking-overview/<int:pk>/', views.admin_booking_detail, name='admin_booking_detail'),
    path('admin/booking-overview/<int:pk>/force-checkout/', views.booking_force_checkout, name='booking_force_checkout'),
    
    # User Views - Booking
    path('book-slot/', views.book_slot, name='book_slot'),
    path('booking/<int:booking_id>/', views.booking_detail, name='booking_detail'),
    path('booking/<int:booking_id>/pass-key/', views.booking_pass_key, name='booking_pass_key'),
    path('booking/<int:booking_id>/invoice/', views.booking_invoice_pdf, name='booking_invoice_pdf'),
    path('checkout/<int:booking_id>/', views.checkout, name='checkout'),
    path('checkout/<int:booking_id>/pass-key/', views.checkout_pass_key, name='checkout_pass_key'),
    path('checkout/<int:booking_id>/payment/', views.checkout_payment, name='checkout_payment'),
    path('booking-history/', views.booking_history, name='booking_history'),
    
    
    # Admin Pass Key Verification
    path('admin/checkout-verify/', views.admin_checkout_verify, name='admin_checkout_verify'),
    path('admin/pass-key-verify/', views.admin_pass_key_verify, name='admin_pass_key_verify'),
    path('admin/complete-checkout/', views.admin_complete_checkout, name='admin_complete_checkout'),
    
    # Payment
    path('payment/<int:booking_id>/process/', views.process_payment, name='process_payment'),
    
    # Theme
    path('theme/set/', views.set_theme, name='set_theme'),
    
    # AJAX
    path('api/slot-status/', views.get_slot_status, name='get_slot_status'),
    
]

