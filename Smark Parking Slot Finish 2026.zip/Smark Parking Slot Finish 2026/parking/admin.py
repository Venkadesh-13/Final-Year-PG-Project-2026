from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, ParkingSlot, Booking, Pricing, VehicleCategory, Notification, Payment


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'role', 'phone', 'created_at']
    list_filter = ['role', 'is_staff', 'is_superuser']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('role', 'phone')}),
    )


@admin.register(Pricing)
class PricingAdmin(admin.ModelAdmin):
    list_display = ['price_per_hour', 'updated_at']


@admin.register(ParkingSlot)
class ParkingSlotAdmin(admin.ModelAdmin):
    list_display = ['slot_number', 'floor_number', 'status', 'created_at']
    list_filter = ['status', 'floor_number']
    search_fields = ['slot_number']


@admin.register(VehicleCategory)
class VehicleCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'multiplier', 'created_at']
    list_filter = ['name']


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'slot', 'vehicle_number', 'vehicle_category', 'start_time', 'end_time', 'total_price', 'status', 'entry_status']
    list_filter = ['status', 'entry_status', 'start_time', 'vehicle_category']
    search_fields = ['user__username', 'vehicle_number', 'slot__slot_number', 'driver_name', 'driver_phone']
    readonly_fields = ['pass_key', 'entry_time', 'exit_time']


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['id', 'booking', 'user', 'amount', 'payment_method', 'payment_status', 'transaction_id', 'payment_date', 'created_at']
    list_filter = ['payment_method', 'payment_status', 'payment_date', 'created_at']
    search_fields = ['user__username', 'booking__id', 'transaction_id', 'booking__vehicle_number']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'booking', 'notification_type', 'title', 'email_sent', 'read', 'created_at']
    list_filter = ['notification_type', 'email_sent', 'read', 'created_at']
    search_fields = ['user__username', 'title', 'message']
    readonly_fields = ['created_at']

