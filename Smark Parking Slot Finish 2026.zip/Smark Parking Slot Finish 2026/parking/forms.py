from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, ParkingSlot, Booking, Pricing


class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))
    phone = forms.CharField(max_length=15, required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    role = forms.ChoiceField(choices=User.ROLE_CHOICES, required=False, initial='user', widget=forms.Select(attrs={'class': 'form-control'}))
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'phone', 'role')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'password1': forms.PasswordInput(attrs={'class': 'form-control'}),
            'password2': forms.PasswordInput(attrs={'class': 'form-control'}),
        }


class ParkingSlotForm(forms.ModelForm):
    class Meta:
        model = ParkingSlot
        fields = ['slot_number', 'floor_number', 'status']
        widgets = {
            'slot_number': forms.TextInput(attrs={'class': 'form-control'}),
            'floor_number': forms.NumberInput(attrs={'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }


class BookingForm(forms.ModelForm):
    start_time = forms.DateTimeField(
        required=True,
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control',
            'type': 'datetime-local',
            'min': ''  # Will be set via JavaScript
        }),
        help_text="Select your booking start time"
    )
    end_time = forms.DateTimeField(
        required=True,
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control',
            'type': 'datetime-local',
            'min': ''  # Will be set via JavaScript
        }),
        help_text="Select your booking end time"
    )
    
    class Meta:
        model = Booking
        fields = [
            'slot', 
            'vehicle_category',
            'vehicle_number', 
            'vehicle_make',
            'vehicle_model',
            'vehicle_color',
            'driver_name',
            'driver_phone',
            'driver_email',
            'start_time',
            'end_time',
            'notes'
        ]
        widgets = {
            'slot': forms.Select(attrs={'class': 'form-control'}),
            'vehicle_category': forms.Select(attrs={'class': 'form-control'}),
            'vehicle_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter vehicle number'}),
            'vehicle_make': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Toyota, Honda'}),
            'vehicle_model': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Camry, Civic'}),
            'vehicle_color': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Red, Blue'}),
            'driver_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Driver name'}),
            'driver_phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone number'}),
            'driver_email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email address'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Additional notes (optional)'}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')
        
        if start_time and end_time:
            from django.utils import timezone
            # Allowed past times as per user request
            # if start_time < timezone.now():
            #     raise forms.ValidationError("Start time cannot be in the past.")
            if end_time <= start_time:
                raise forms.ValidationError("End time must be after start time.")
        
        return cleaned_data


class PricingForm(forms.ModelForm):
    class Meta:
        model = Pricing
        fields = ['price_per_hour']
        widgets = {
            'price_per_hour': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
        }

