# Generated manually for replacing QR code with pass key

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('parking', '0007_delete_systemsettings'),
    ]

    operations = [
        migrations.RenameField(
            model_name='booking',
            old_name='qr_code',
            new_name='pass_key',
        ),
        migrations.AlterField(
            model_name='booking',
            name='pass_key',
            field=models.CharField(blank=True, help_text='Unique pass key for verification', max_length=20, null=True, unique=True),
        ),
    ]

