# Parking Booking System

A comprehensive Django-based parking management system with role-based access control, real-time slot availability, dynamic pricing, and modern UI.

## Features

### Admin Module
- **Dashboard**: Analytics with charts, revenue tracking, and statistics
- **Slot Administration**: Add, edit, delete, and toggle parking slots
- **Pricing Configuration**: Configure hourly rates with flexible pricing rules
- **User Administration**: Create, view, and manage users
- **Booking Overview**: View all bookings with filters
- **Analytics**: Daily, weekly, and monthly revenue reports with charts
- **QR Code Scanning**: Scan QR codes for entry and exit confirmation
- **Payment Management**: View and track all payment transactions

### User Module
- **Registration & Login**: Secure authentication system
- **Real-Time Availability**: View available, booked, and maintenance slots
- **Slot Booking**: Book available slots with vehicle number
- **QR Code Generation**: Automatic QR code for contactless entry
- **Dynamic Checkout**: Automatic price calculation based on duration
- **Digital Payments**: Multiple payment methods (Stripe, PayPal, Card, Cash)
- **Email Notifications**: Booking confirmations and checkout summaries with attachments
- **PDF Invoices**: Download invoices and receive via email
- **Booking History**: View past bookings and receipts
- **Theme Switcher**: Multiple color themes (Light, Dark, Blue, Green, Purple)

## Technical Stack

- **Backend**: Python 3.x, Django 4.2+
- **Database**: SQLite3
- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript, Chart.js
- **Authentication**: Django's built-in authentication with custom user model
- **Email**: SMTP email support with HTML emails and attachments
- **Payments**: Stripe integration (configurable)
- **QR Codes**: QR code generation and scanning
- **PDF Generation**: ReportLab for invoice generation

## Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd "Smark Parking Slot"
   ```

2. **Create a virtual environment (recommended):**
   ```bash
   python -m venv venv
   venv\Scripts\activate  # On Windows
   # or
   source venv/bin/activate  # On Linux/Mac
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run migrations:**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create a superuser (admin account):**
   ```bash
   python manage.py createsuperuser
   ```

6. **Run the development server:**
   ```bash
   python manage.py runserver
   ```

7. **Access the application:**
   - Open your browser and go to: `http://127.0.0.1:8000/`
   - Admin panel: `http://127.0.0.1:8000/admin/`

## Initial Setup

1. **Login as admin** using the superuser credentials you created.

2. **Add Parking Slots:**
   - Navigate to Admin → Slots
   - Click "Add New Slot"
   - Enter slot number, floor number, and status

3. **Configure Pricing:**
   - Navigate to Admin → Pricing
   - Set hourly rates, first hour rate, and additional hour rates

4. **Create Users (optional):**
   - Navigate to Admin → Users
   - Create user accounts or let users register themselves

## Usage

### For Administrators

1. **Dashboard**: View overall statistics, revenue, and recent bookings
2. **Slot Management**: Manage all parking slots, change status with one click
3. **Pricing**: Update parking rates as needed
4. **User Management**: Approve, create, or delete users
5. **Bookings**: View all bookings, filter by status/date, force checkout if needed

### For End Users

1. **Register/Login**: Create an account or login
2. **View Availability**: See real-time slot availability on the dashboard
3. **Book Slot**: Select an available slot and enter vehicle number
4. **Checkout**: When leaving, checkout to calculate and pay for parking
5. **History**: View all past bookings

## Database Models

- **User**: Custom user model with role (admin/user)
- **ParkingSlot**: Slot number, floor, status (available/booked/maintenance)
- **Booking**: User, slot, vehicle number, start/end time, price calculation, QR code
- **Pricing**: Hourly rates configuration
- **Payment**: Payment records with transaction tracking
- **Notification**: Email and SMS notification tracking
- **VehicleCategory**: Vehicle categories with price multipliers

## Pricing Calculation

The system supports flexible pricing:
- **First Hour**: Fixed rate (e.g., $10)
- **Additional Hours**: Per-hour rate (e.g., $10/hour)
- **Example**: 3 hours = $10 (first) + $20 (2 additional) = $30

## Features Highlights

- ✅ Role-based access control
- ✅ Real-time slot status updates
- ✅ Automatic price calculation
- ✅ Modern, responsive UI with theme switcher
- ✅ Analytics and reporting with Chart.js
- ✅ AJAX for live updates
- ✅ Professional dashboard with charts
- ✅ Automatic slot status management
- ✅ QR code generation and scanning
- ✅ Email notifications with QR code and PDF attachments
- ✅ Digital payment integration (Stripe, PayPal, etc.)
- ✅ PDF invoice generation and email delivery
- ✅ Meaningful module names (Slot Administration, Pricing Configuration, etc.)

## Project Structure

```
parking_system/
├── manage.py
├── parking_system/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── parking/
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── forms.py
│   └── admin.py
├── templates/
│   ├── base.html
│   ├── parking/
│   │   ├── login.html
│   │   ├── register.html
│   │   ├── admin/
│   │   └── user/
└── static/
```

## Development

To add new features or modify existing ones:

1. Models are in `parking/models.py`
2. Views are in `parking/views.py`
3. Templates are in `templates/parking/`
4. URLs are configured in `parking/urls.py`

## License

This project is created for educational and commercial purposes.

## Configuration

### Email Setup
See [EMAIL_CONFIGURATION.md](EMAIL_CONFIGURATION.md) for detailed email configuration instructions.

### Payment Setup
See [PAYMENT_SETUP.md](PAYMENT_SETUP.md) for payment integration instructions.

## Additional Documentation

- **Email Configuration**: See `EMAIL_CONFIGURATION.md`
- **Payment Setup**: See `PAYMENT_SETUP.md`
- **Admin URLs**: See `ADMIN_URLS.md`
- **Features**: See `FEATURES.md`
- **Setup Guide**: See `SETUP.md`

## Support

For issues or questions, please check the code comments or Django documentation.

---

**Developed with ❤️ using Django**

