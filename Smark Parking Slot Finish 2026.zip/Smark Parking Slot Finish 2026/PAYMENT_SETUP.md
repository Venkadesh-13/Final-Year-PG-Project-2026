# Payment Integration Setup Guide

This guide explains how to set up payment processing for the Parking Booking System.

## Payment Features

The system supports multiple payment methods:
- **Stripe** (Credit/Debit Cards) - Recommended
- **PayPal**
- **Card Payment**
- **Online Payment**
- **Cash**

## Stripe Integration (Recommended)

### Setup Steps

1. **Create a Stripe Account**
   - Go to https://stripe.com
   - Sign up for a free account
   - Get your API keys from the Dashboard

2. **Install Stripe Python Library** (Already in requirements.txt)
   ```bash
   pip install stripe
   ```

3. **Get Your API Keys**
   - **Test Keys** (for development):
     - Publishable key: `pk_test_...`
     - Secret key: `sk_test_...`
   - **Live Keys** (for production):
     - Publishable key: `pk_live_...`
     - Secret key: `sk_live_...`

4. **Add Stripe Keys to Settings**

   Option 1: Direct in `settings.py` (for development):
   ```python
   STRIPE_PUBLISHABLE_KEY = 'pk_test_your_publishable_key'
   STRIPE_SECRET_KEY = 'sk_test_your_secret_key'
   ```

   Option 2: Environment variables (recommended for production):
   ```python
   import os
   
   STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY', '')
   STRIPE_SECRET_KEY = os.environ.get('STRIPE_SECRET_KEY', '')
   ```

5. **Update Payment Processing View**

   The payment processing is currently simulated. To integrate real Stripe payments:

   ```python
   import stripe
   from django.conf import settings
   
   stripe.api_key = settings.STRIPE_SECRET_KEY
   
   @login_required
   def process_payment(request, booking_id):
       booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
       
       if request.method == 'POST':
           try:
               # Create Stripe payment intent
               intent = stripe.PaymentIntent.create(
                   amount=int(booking.total_price * 100),  # Convert to cents
                   currency='usd',
                   metadata={'booking_id': booking.id}
               )
               
               # Create payment record
               payment = Payment.objects.create(
                   booking=booking,
                   user=request.user,
                   amount=booking.total_price,
                   payment_method='stripe',
                   payment_status='completed',
                   payment_date=timezone.now(),
                   transaction_id=intent.id,
               )
               
               return JsonResponse({
                   'success': True,
                   'client_secret': intent.client_secret,
                   'payment_id': payment.id,
               })
           except stripe.error.StripeError as e:
               return JsonResponse({
                   'success': False,
                   'message': str(e)
               })
   ```

## Frontend Integration (Stripe Elements)

To add Stripe payment form to checkout page:

1. **Add Stripe.js to checkout template**:
   ```html
   <script src="https://js.stripe.com/v3/"></script>
   ```

2. **Create payment form**:
   ```html
   <form id="payment-form">
       <div id="card-element"></div>
       <button type="submit">Pay</button>
   </form>
   ```

3. **Initialize Stripe**:
   ```javascript
   const stripe = Stripe('{{ STRIPE_PUBLISHABLE_KEY }}');
   const elements = stripe.elements();
   const cardElement = elements.create('card');
   cardElement.mount('#card-element');
   ```

## PayPal Integration

1. **Create PayPal Developer Account**
   - Go to https://developer.paypal.com
   - Create an app and get Client ID and Secret

2. **Install PayPal SDK**:
   ```bash
   pip install paypalrestsdk
   ```

3. **Configure in settings.py**:
   ```python
   PAYPAL_CLIENT_ID = os.environ.get('PAYPAL_CLIENT_ID', '')
   PAYPAL_CLIENT_SECRET = os.environ.get('PAYPAL_CLIENT_SECRET', '')
   PAYPAL_MODE = 'sandbox'  # or 'live' for production
   ```

## Current Implementation

Currently, the system:
- Creates payment records in the database
- Simulates payment processing
- Supports multiple payment methods
- Tracks payment status and transaction IDs

## Testing Payments

### Test Mode
- Use test API keys
- Test cards provided by Stripe/PayPal
- No real money is charged

### Test Cards (Stripe)
- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- Requires 3D Secure: `4000 0025 0000 3155`

## Production Checklist

- [ ] Switch to live API keys
- [ ] Implement proper error handling
- [ ] Add payment webhooks for status updates
- [ ] Set up payment receipts
- [ ] Configure refund handling
- [ ] Add payment analytics
- [ ] Implement PCI compliance measures
- [ ] Test all payment methods
- [ ] Set up payment notifications

## Security Considerations

1. **Never expose secret keys** in client-side code
2. **Use HTTPS** in production
3. **Validate payments server-side**
4. **Store transaction IDs** for reference
5. **Implement webhook verification**
6. **Log all payment attempts**
7. **Handle failed payments gracefully**

## Support

- Stripe Documentation: https://stripe.com/docs
- PayPal Documentation: https://developer.paypal.com/docs
- Django Payments: Consider using `django-payments` package for easier integration

