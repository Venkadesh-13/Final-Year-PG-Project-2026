# Admin URLs Reference

## Accessing Admin Pages

All admin pages require you to be **logged in as an admin user**.

### Admin URLs:

1. **Slots Management:**
   - List: http://127.0.0.1:8000/admin/slots/
   - Create: http://127.0.0.1:8000/admin/slots/create/
   - Edit: http://127.0.0.1:8000/admin/slots/{id}/edit/
   - Delete: http://127.0.0.1:8000/admin/slots/{id}/delete/

2. **Pricing Management:**
   - Manage: http://127.0.0.1:8000/admin/pricing/

3. **User Management:**
   - List: http://127.0.0.1:8000/admin/users/
   - Create: http://127.0.0.1:8000/admin/users/create/
   - Delete: http://127.0.0.1:8000/admin/users/{id}/delete/

4. **Bookings Management:**
   - List: http://127.0.0.1:8000/admin/bookings/
   - Force Checkout: http://127.0.0.1:8000/admin/bookings/{id}/force-checkout/

## Important Notes:

- **Django Admin Panel** is now at: http://127.0.0.1:8000/django-admin/ (changed to avoid conflicts)
- You must be logged in with an admin account
- Admin accounts have `role='admin'` or are superusers

## Troubleshooting:

If you get "Page Not Found" errors:

1. **Check if you're logged in:**
   - Go to http://127.0.0.1:8000/login/
   - Login with admin credentials

2. **Verify you're an admin:**
   - Your user must have `role='admin'` in the database
   - Or be a superuser (created with `createsuperuser`)

3. **Check the server is running:**
   ```bash
   python manage.py runserver
   ```

4. **Verify URLs are correct:**
   - Make sure you're using the exact URLs listed above
   - Check for typos in the URL

## Quick Access from Dashboard:

Once logged in as admin, you can access all admin pages from the navigation menu:
- Click on "Admin" dropdown in the navbar
- Select: Slots, Pricing, Users, or Bookings

