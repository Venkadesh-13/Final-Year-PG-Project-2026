"""
Script to create an admin user non-interactively.
Run this script to create a superuser account.
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'parking_system.settings')
django.setup()

from parking.models import User

def create_admin():
    username = input("Enter username: ")
    email = input("Enter email: ")
    password = input("Enter password: ")
    
    if User.objects.filter(username=username).exists():
        print(f"User '{username}' already exists!")
        return
    
    user = User.objects.create_superuser(
        username=username,
        email=email,
        password=password,
        role='admin'
    )
    print(f"Superuser '{username}' created successfully!")

if __name__ == '__main__':
    create_admin()

